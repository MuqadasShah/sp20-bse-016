import React from 'react';
import { StyleSheet, View } from 'react-native';
function StepsBoxes(props) {
    return (
        <View>
             <View style={styles.Row1}>
                <View style={styles.Button}></View>
                <View style={styles.Button}></View>
                </View>
                <View style={styles.Row1}>
                    <View style={styles.Button}></View>
                     <View style={styles.Button}></View>
                </View>
        </View>
    );
}

export default StepsBoxes;
const styles = StyleSheet.create({
    Button:{
        width:25,
        height:25,
        borderRadius:50,
        backgroundColor:'white',
        marginLeft:7,
        marginTop:8,
     
    },
    Row1:{
        flexDirection:'row'
    },
});